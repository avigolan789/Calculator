package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView result;
    Integer num1;
    Integer num2;
    char operaor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result = findViewById(R.id.textViewresult);
    }

    public void buttonFunctionNumber(View view) {
        if ((view instanceof Button)) {
            Button b = (Button) view;
            String str = b.getText().toString();
            result.append(str);
        }

    }

    public void buttonFunctionOperation(View view) {

        Button b = (Button) view;
        operaor = b.getText().toString().charAt(0);
        num1 = Integer.parseInt(result.getText().toString());
        result.setText("");
    }

    public void buttonFunctionEqual(View view)
    {
       double sum = 0.00;
        num2 = Integer.parseInt(result.getText().toString());
        switch (operaor) {
            case '+':
                sum = num1 + num2;
                break;
            case '-':
                sum = num1 - num2;
                break;
            case '*':
                sum = num1 * num2;
                break;
            case '/':
                if (num2 != 0)
                    sum = (double) num1 / num2;
                else {
                    result.setText("Division by zero)");
                    return;
                }
                break;
        }
        result.setText(String.valueOf(sum));
    }

    public void buttonFunctionClear(View view) {
        result.setText("");
    }
}